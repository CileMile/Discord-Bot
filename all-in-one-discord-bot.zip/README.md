# Rock-Official---Advance-Discord-Bot-With-Advance-Moderation-Advance-Music-System
Rock Official - Advance Discord Bot With Advance Moderation , Advance Music System , Much More

#Need a hosting to host a minecraft server or discord bot server 24/7 ? I recommend using https://futurehosting.org/ . They provide 24/7 server hosting with best performance at affordable price and discounts . They also have 24/7 support on their discord and site .

Site : https://futurehosting.org/

Discord : https://discord.gg/DNme6pzFQB

Order discord bot server : https://billing.futurehosting.org/index.php?rp=/store/discord-bot-voice-hosting

## ** Invite Public Version **
[Invite Now](https://discord.com/oauth2/authorize?client_id=856953042029379604&scope=bot&permissions=8)


## Credits

[@tomato](https://github.com/Tomato6966/) For the Reacting system to messages, great Idea i adopted that [@Tomato6966/Musicium](https://github.com/Tomato6966/Musicium)
[@tomato](https://github.com/Tomato6966/) For the Reacting system to messages, great Idea, I adopted that [@Tomato6966/Musicium](https://github.com/Tomato6966/Musicium)

Thanks For Tomato6966
Check Out Tomato6966 Gtihub Repo
